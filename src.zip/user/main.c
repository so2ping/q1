#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "LED.h"
#include "KEY.h"
//key输出keynum，控制flag，flag=1，全亮，flag=2流水灯，i控制哪个灯，
uint8_t KEYNum;
uint16_t flag=0;
uint8_t i=0;
int main(void)
	{
	LED_Init();
	KEY_Init();
		
	while(1)
	{
		KEYNum = KEY_GetNum ();
		if(KEYNum==1)
		{
			
			i=0;
			if(flag==1|flag==2){
			flag =0;
			}
			else{
			flag=1;}
		}
		else if(KEYNum==2&flag==1)
		{
			flag=2;
		}
	
	
		if(flag==1)
		{	
			LED_SET (GPIOA,0x0001,0);
				LED_SET (GPIOA,0x0004,0);
				LED_SET (GPIOA,0x0002,0);
			
			
		}
		
		else if(flag==2)
		{
			if(i==0){//用GPIO_WriteBit总是出小问题，索性直接朴素了
				LED_SET (GPIOA,0x0001,0);
				LED_SET (GPIOA,0x0004,1);
				LED_SET (GPIOA,0x0002,1);
			}
			else if(i==1)
			{
			LED_SET (GPIOA,0x0002,0);
			LED_SET (GPIOA,0x0001,1);
			LED_SET (GPIOA,0x0004,1);}
			else if(i==2)
			{LED_SET (GPIOA,0x0004,0);
			LED_SET (GPIOA,0x0002,1);
			LED_SET (GPIOA,0x0001,1);
			}
			i++;
			if(i>=3)i=0;
			Delay_ms(500);
		}
		if(flag==0){
			LED_SET (GPIOA,0x0002,1);
			LED_SET (GPIOA,0x0001,1);
			LED_SET (GPIOA,0x0004,1);}
			
}

}
