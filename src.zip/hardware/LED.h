#ifndef __LED_H
#define __LED_H
 void LED_Init(void);//状态
void LED_SET(GPIO_TypeDef *GPIOx, uint16_t pin,uint16_t stuas);//开关stuas是0 低，
void LED_TURN(GPIO_TypeDef *GPIOx, uint16_t pin,uint16_t stuas);//利用电平反转控制灯泡亮灭

#endif