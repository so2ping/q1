#ifndef __KEY_H
#define __KEY_H
uint8_t KEY_GetNum(void);//GetNum=0|1|2，1控制B0，2为B11
void KEY_Init(void);//状态

#endif