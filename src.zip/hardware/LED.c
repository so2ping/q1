#include "stm32f10x.h"     // Device header

void LED_Init(void)
{//初始化
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	GPIO_InitTypeDef GPIO_Initstructure;
	GPIO_Initstructure.GPIO_Mode=GPIO_Mode_Out_PP;;
	GPIO_Initstructure.GPIO_Pin=GPIO_Pin_All;
	GPIO_Initstructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_Initstructure);
	GPIO_SetBits(GPIOA,GPIO_Pin_All);
}
void LED_SET(GPIO_TypeDef *GPIOx, uint16_t pin,uint16_t stuas)
{//上下两个没区别，只是上面AB，都可以，下面只支持A口，不过开启时钟只开了A的，所以没区别，1表示关，当然接线为vcc接pin口
	
	if(stuas == 1)
	{GPIO_SetBits(GPIOx,pin);
		
	
	}
	else
	{GPIO_ResetBits (GPIOx,pin);
		
	}
}	
void LED_TURN(GPIO_TypeDef *GPIOx, uint16_t pin,uint16_t stuas)
{
	if (stuas==1)
	{	if (GPIO_ReadOutputDataBit(GPIOA,pin)==0)
		{
			GPIO_SetBits (GPIOA,pin);
		}
		else 
		{
			GPIO_ResetBits (GPIOA,pin);
		}
		
			
	}
}	

